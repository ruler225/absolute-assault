import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.*;

public class gamepanel extends JPanel implements KeyListener, ActionListener{
  private BufferedImage backgroundImg;
  private inanimate[][] tiles;
  private Player player;
  
  private static BufferedImage gr = null;
  private static BufferedImage  le= null;
  private static BufferedImage re = null;
  private static BufferedImage r1b = null;
  private static BufferedImage r1 = null;
  private static BufferedImage m = null;
  private static BufferedImage mb = null;
  private static BufferedImage l1 = null;
  private static BufferedImage l1b = null;
  private static BufferedImage b = null;
  
  JTextArea area = new JTextArea();
  
   Timer thetimer;
  
  public gamepanel() {
//    area.setSize(200, 100);
//    area.setLocation(0, 0);
//    this.add(area);
    
    try {
      backgroundImg = ImageIO.read(new File("../BackGrounds/sky.png"));
      r1 = ImageIO.read(new File("../Map/island/R1.png"));
      r1b = ImageIO.read(new File("../Map/island/R1B.png"));
      l1 = ImageIO.read(new File("../Map/island/L1.png"));
      l1b = ImageIO.read(new File("../Map/island/L1B.png"));
      m = ImageIO.read(new File("../Map/island/M.png"));
      mb = ImageIO.read(new File("../Map/island/MB.png"));
      le = ImageIO.read(new File("../Map/grassplatform/le.png"));
      re = ImageIO.read(new File("../Map/grassplatform/re.png"));
      gr = ImageIO.read(new File("../Map/grassplatform/grass.png"));
      b  = ImageIO.read(new File("../Map/grassplatform/black.png"));
      
      //read csv file
      BufferedReader br = null;
      
      int x = 0;
      int y = 0;
      
      br = new BufferedReader(new FileReader("../Map/Level1.csv"));
      tiles = new inanimate[6][13]; //make one dimensional cause the objects already have the info (to simply the check collison)
      
      //al the xs and ys are in the object already, use one dimensional array to read map/////////////////////////////////////////////////////////////////////
      String line;
      inanimate current;
      for (int i = 0; i<6; i++) {
        line = br.readLine();
        x = 0;
        String str[] = line.split(",");
        for (int j = 0; j < str.length; j++) {                 //TODO
          // tileType = TileType.valueOf(str[j]);
          current = createInanimate(str[j], x, y);
          
          x = x + current.getWidth();
          
          tiles[i][j] = current;
        }
        y = y + 100;
      }
      
      readImgForPlayers();
      
    } catch (IOException e1) {
      // TODO Auto-generated catch block
      e1.printStackTrace();
    }
    this.addKeyListener(this);
   //this.addActionListener(this);
        // Contruct a new timer that will trigger an actionevent
    // every specific number of milliseconds
    // 1000/30 - Most games/movies use a frame rate of 30 frames per second
    // There are 1000 ms in a second.  Therefore 1000/30 = 30 frames per second
    thetimer = new Timer(1000/60, this);
    // Start the timer
    thetimer.start();
  }
  
  // set the second panel (the game panel) to be focusable so that it can respond to listeners
  public void addNotify(){
    super.addNotify();
    requestFocus();
    
  }
  
  /**
   * Paint
   **/
  public void paintComponent(Graphics g) {
    g.clearRect(0, 0, 1280, 720);
    g.drawImage(backgroundImg,0,0,null);
    if(tiles != null){
      inanimate tile;
      for (int i = 0; i < tiles.length; i++) {
        for (int j = 0; j < tiles[i].length; j++) {
          tile = tiles[i][j];
          if (tile != null) {
            tile.drawObject(g);
          }
        }
      }
    }
    
    if (player != null) {
   /*  for(;;){
        if(player.checkCollision(tiles[6][13])){
          player.blnAirborne = false;
        }
      }
      
     */ 
      
      //System.out.println("hi  " +player.intState);
       //System.out.println(player.intCurrentFrame);
        //System.out.println(player.intCurrentCounter);
      player.updateFrameCounter();
      player.updatePhysics();
      
      
      //System.out.println(player.intState);
       //System.out.println(player.intCurrentFrame);
        //System.out.println(player.intCurrentCounter);
      player.drawObject(g);
    }
  }
  
  
  public void setTiles(inanimate[][] tiles) {
    this.tiles = tiles;
  }
  
  public void setPlayer(Player player) {
    this.player = player;
  }
  public void setImage(BufferedImage image) {
    this.backgroundImg=  image;
  }
  
  private inanimate createInanimate(String code, int x, int y) {
    BufferedImage image = null;    
    code = code.toLowerCase();
    
    switch (code) {
      case "gr":
        image = gr;
        break;
      case "le":
        
        image = le;
        break;
      case "re":
        image = re;
        break;
        
      case "l1":
        
        image = l1;
        break;
      case"l1b":
        image = l1b;
        break;
      case "r1":
        image = r1;
        break;
      case"r1b":
        
        image = r1b;
        break;
      case "m":
        image = m;
        break;
      case "mb":
        image = mb;
        break;
        
      case "b":
        image = b;
        break;
        
        
      default:
        image = null;
        break;
    }
    if (image != null)
      return new inanimate(x, y, image.getWidth(), image.getHeight(), image);
    else {
      return new inanimate(x, y, 100, 100, null);
    }
    
  }
  @Override
  public void keyPressed(KeyEvent e) {
  
    int keyCode = e.getKeyCode();
    switch( keyCode ) { 
      case KeyEvent.VK_F1:
        
        //Shoot attack
        // what is last state
       //player.currentDirection = Direction.Right;
        player.setAnimationState(5);
        break;
       case KeyEvent.VK_F2:
        
        //Shoot attack
        // what is last state
       //player.currentDirection = Direction.Right;
        player.setAnimationState(6);
        break;
      case KeyEvent.VK_UP:
        // handle up 
       player.jump();
        
        break;
      case KeyEvent.VK_DOWN:
        if (player.intY  < 300) {
        player.intY ++;
      }
        // handle down 
        break;
      case KeyEvent.VK_LEFT:
        // handle left
        
       player.currentDirection = Direction.Right;
        player.setAnimationState(3);
        player.intX -= 5;
        break;
      case KeyEvent.VK_RIGHT :
        // update state of player
        player.currentDirection = Direction.Right;
        player.setAnimationState(2);
        player.intX += 5;
        break;
    }
    
  }
  
  public void actionPerformed(ActionEvent evt){
    if(evt.getSource() == thetimer){
    
        repaint();
    }
    
  }
  @Override
  public void keyReleased(KeyEvent arg0) {
    // TODO Auto-generated method stub
     player.setAnimationState(0);
    //System.out.println("key released");
    
  }
  
  @Override
  public void keyTyped(KeyEvent arg0) {
    // TODO Auto-generated method stub
    //System.out.println("key typed");
    
  }
  
  // Character states
  public void readImgForPlayers() {
    BufferedImage spriteSheet[][] = new BufferedImage[8][4];
    File folder = new File("../Character/standright");
    listFilesForFolder(folder, spriteSheet[0]);
    
    folder = new File("../Character/attackLeft");
    listFilesForFolder(folder, spriteSheet[1]);
    
    folder = new File("../Character/walkright");
    listFilesForFolder(folder, spriteSheet[2]);
    
    folder = new File("../Character/walkleft");
    listFilesForFolder(folder, spriteSheet[3]);
    
    folder = new File("../Character/standleft");
    listFilesForFolder(folder, spriteSheet[4]);
    folder = new File("../Character/attackright");
    listFilesForFolder(folder, spriteSheet[5]);
    folder = new File("../Character/jumpright");
    listFilesForFolder(folder, spriteSheet[6]);
    folder = new File("../Character/jumpleft");
    listFilesForFolder(folder, spriteSheet[7]);
    
    //System.out.println("=================================================================================================================================================================================================================================================================================");
      player = new Player(200,200,45,70,spriteSheet,true);
    
  }
  
  public void listFilesForFolder(final File folder, BufferedImage imagesForState[]) {
    int i = 0;
    for (final File fileEntry : folder.listFiles()) {
      
      // load image.....
      try {
        //System.out.println(fileEntry);
        BufferedImage image = ImageIO.read(fileEntry);
        imagesForState[i] = image;
        i ++;
      }catch(IOException e){
      }
      
      
    }
    
  }
  
  
  public static void main(String[] args) {
    // JFrame f = new JFrame("Window");
    // f.add(new JGraphics());
    // f.setSize(image.getWidth(), image.getHeight() + 30);
    // f.setVisible(true);
  }
}

//Load all ements in a 2d string array. Strsplit.
//Iterate through that array using a for loop, draw elements depending on the index number


//Animates
//Make a 2d array or pictures for each character.
//Load those ni a for loop
//Create a new animate object using constructor



//The load the map in a 2 dimensional array, go through throuh each element in the array depending on the index array

