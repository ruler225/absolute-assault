import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.*;

public class menupanel extends JPanel{
    private BufferedImage backgroundImg;

     
    
   
    public menupanel() {
      try{
         backgroundImg = ImageIO.read(new File("../BackGrounds/MenuBackGround.png"));
      }catch(IOException e) {
      }
        
      
    }

    public void paintComponent(Graphics g) {
        g.clearRect(0, 0, 1280, 720);
        g.drawImage(backgroundImg,0,0,null);
        
        repaint();
    }

}

//Load all ements in a 2d string array. Strsplit.
//Iterate through that array using a for loop, draw elements depending on the index number


//Animates
//Make a 2d array or pictures for each character.
//Load those ni a for loop
//Create a new animate object using constructor

