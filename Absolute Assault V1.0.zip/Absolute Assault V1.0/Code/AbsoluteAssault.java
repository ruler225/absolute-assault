import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.*;

// fix need to substract 1 in animate for //todo fix need to substract 1   public void nextSpriteFrame(){
// todo fixanimate..the constructor
// animate, need a previous state to decide next state
public class AbsoluteAssault implements ActionListener, KeyListener{
  
  //Properties
  public JFrame theFrame;
  
  public JButton singlePlayerButton;
  
  public JButton cooperativeButton;
  
  public JButton helpButton;
  
  public menupanel menu;
  
  public gamepanel game;
  
  public JTextArea chatbox;

  //Methods
  
  
  public void actionPerformed(ActionEvent evt) {
    
    if(evt.getSource() == singlePlayerButton ){
      
      startSinglePlayer();
    }
    
  }
  
  public void keyReleased(KeyEvent evt){
    
  }
  
  public void keyPressed(KeyEvent evt){
  }
  
  public void keyTyped(KeyEvent evt){
    
  }
  
  public AbsoluteAssault(){
    theFrame = new JFrame("Absolute Assault");
    theFrame.setResizable(false);
    theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    menu = new menupanel();
    
    // set the images
    
    menu.setLayout(null);
    menu.setPreferredSize(new Dimension(1280, 720));
    singlePlayerButton = new JButton("Single Player");
    singlePlayerButton.setSize(450, 50);
    singlePlayerButton.setLocation(800, 200);
    singlePlayerButton.addActionListener(this);
    
    cooperativeButton = new JButton("Cooperative");
    cooperativeButton.setSize(450, 50);
    cooperativeButton.setLocation(800, 300);
    cooperativeButton.addActionListener(this);
    
    helpButton = new JButton("Help");
    helpButton.setSize(450, 50);
    helpButton.setLocation(800, 400);
    helpButton.addActionListener(this);
    
    menu.add(singlePlayerButton);
    menu.add(cooperativeButton);
    menu.add(helpButton);
    menu.addKeyListener(this);
    
    theFrame.setContentPane(menu);
    
    theFrame.pack();
    
    theFrame.setVisible(true);
    
    menu.repaint();    
    
  }
  private void startSinglePlayer(){
    
    //  singlePlayerButton.setVisible(false);
    // cooperativeButton.setVisible(false);
    // helpButton.setVisible(false);
    // theFrame.remove(menu);  \//TODO remove the old panel
    
    game = new gamepanel();
   
    //game.setFocusable(true);
    game.setPreferredSize(new Dimension(1280, 720));
    game.setLayout(null);
    
    chatbox = new JTextArea();
    chatbox.setSize(200,100);
    chatbox.setLocation(1170, 510);
    game.add(chatbox);
     theFrame.setContentPane(game);
    
    theFrame.pack();

  }
  public static void main (String args []){
    
    AbsoluteAssault game = new AbsoluteAssault();

  }  
}


//So ummm, when yoiu press a key sucj as right it would set blnMovingLeft os something liekt aht to true. And that thae charracter would be moving right at everyframe. And when key relased set back to false.
