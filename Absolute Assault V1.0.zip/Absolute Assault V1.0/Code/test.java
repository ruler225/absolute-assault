package game;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;

public class AbsoluteAssault implements ActionListener, MouseListener, MouseMotionListener, KeyListener  {

    private static BufferedImage backgroundImage1 = null;

    // properties
    private static BufferedImage backgroundImageSinglePlayer = null;

    public JFrame theFrame;

    public JButton singlePlayerButton;

    public JButton theButton2;

    public JButton theButton3;

    public JGraphics thePanel;


    private static final String path = "F:/Absolute Assault/";
    
    private static Player player;


    // private static BufferedImage backgroundImageSinglePlayer = null;

    private static InAnimate[][] tiles = new InAnimate[14][5];

    Timer thetimer;

    // Methods
    public void actionPerformed(ActionEvent evt) {

    }

    public void mouseExited(MouseEvent evt) {

    }

    public void mouseEntered(MouseEvent evt) {
  
    }

    public void mouseReleased(MouseEvent evt) {
    
    }

    public void mousePressed(MouseEvent evt) {

    }

    public void mouseClicked(MouseEvent evt) {

    }

    public void mouseMoved(MouseEvent evt) {

    }

    public void mouseDragged(MouseEvent evt) {

    }

    public AbsoluteAssault() {
        try {
            backgroundImage1 = ImageIO.read(new File(
                   path + "BackGrounds/MenuBackGround.png"));
        
        } catch (IOException e1) }
        }

        singlePlayerButton = new JButton("Single Player");
        singlePlayerButton.setSize(450, 50);
        singlePlayerButton.setLocation(800, 200);

        theButton2 = new JButton("Cooperative");

        theButton2.setSize(450, 50);
        theButton2.setLocation(800, 300);
        theButton3 = new JButton("Help");

        theButton3.setSize(450, 50);
        theButton3.setLocation(800, 400);
        theFrame = new JFrame("Absolute Assault");
        theFrame.setLocation(0, 0);
        theFrame.setResizable(false);
        theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        thePanel = new JGraphics();
        tiles = new InAnimate[1][1];
        tiles[0][0] = new InAnimate(0, 0, 1280, 720, backgroundImage1);
        thePanel.setTiles(tiles);

        thePanel.add(singlePlayerButton);
        singlePlayerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Set up for single player;
                startSinglePlayer();
            }

        });

        thePanel.add(theButton2);
        thePanel.add(theButton3);

        thePanel.addMouseMotionListener(this);
        thePanel.addKeyListener(this);
        thePanel.setLayout(null);
        thePanel.addMouseListener(this);
        thePanel.setFocusable(true);
        thePanel.setPreferredSize(new Dimension(1280, 720));
        theFrame.setContentPane(thePanel);
        theFrame.pack();
        theFrame.setVisible(true);

    }

    public static void main(String[] args) {

        AbsoluteAssault mm = new AbsoluteAssault();

        //

    }

    private void startSinglePlayer() {
     singlePlayerButton.setVisible(false);
     theButton2.setVisible(false);
     theButton3.setVisible(false);
     
    }
    }