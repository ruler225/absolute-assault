package game;

import java.awt.Graphics;

import javax.swing.JPanel;

public class JGraphics extends JPanel {

    private GameObject[][] tiles;
    private Player player;

    public JGraphics() {
    }

    public void paintComponent(Graphics g) {
        g.clearRect(0, 0, 1280, 720);
         animate tile;
        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                tile = tiles[i][j];
                if (tile != null) {
                    tile.drawObject(g);
                }
            }
        }
        player.updatePhysics();
        if (player != null) {
         player.drawObject(g);
        }
        repaint();
    }


    public void setTiles(GameObject[][] tiles) {
        this.tiles = tiles;
    }
    
    public void setPlayer(Player player) {
     this.player = player;
    }

    public static void main(String[] args) {
        // JFrame f = new JFrame("Window");
        // f.add(new JGraphics());
        // f.setSize(image.getWidth(), image.getHeight() + 30);
        // f.setVisible(true);
    }
}