package game;

import java.awt.Graphics;

public class GameElements {

    private GameObject[][] tiles;
    
	public void drawObjects(Graphics g) {
		// TODO Auto-generated method stub
    	
	      
        GameObject tile;
        for (int i = 0; i < tiles.length; i++) {
            for (int j = 0; j < tiles[i].length; j++) {
                tile = tiles[i][j];
                if (tile != null) {
                    tile.drawObject(g);
                }
            }
        }
	}

}
