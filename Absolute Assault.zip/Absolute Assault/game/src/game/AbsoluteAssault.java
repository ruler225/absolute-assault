package game;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;

public class AbsoluteAssault implements ActionListener, MouseListener, MouseMotionListener, KeyListener  {

    private static BufferedImage backgroundImage1 = null;

    // properties
    private static BufferedImage backgroundImageSinglePlayer = null;

    public JFrame theFrame;

    public JButton singlePlayerButton;

    public JButton theButton2;

    public JButton theButton3;

    public JGraphics thePanel;


    private static final String path = "F:/Absolute Assault/";
    
    private static Player player;


    // private static BufferedImage backgroundImageSinglePlayer = null;

    private static InAnimate[][] tiles = new InAnimate[14][5];

    Timer thetimer;

    // Methods
    public void actionPerformed(ActionEvent evt) {

    }

    public void mouseExited(MouseEvent evt) {

    }

    public void mouseEntered(MouseEvent evt) {
  
    }

    public void mouseReleased(MouseEvent evt) {
    
    }

    public void mousePressed(MouseEvent evt) {

    }

    public void mouseClicked(MouseEvent evt) {

    }

    public void mouseMoved(MouseEvent evt) {

    }

    public void mouseDragged(MouseEvent evt) {

    }

    public AbsoluteAssault() {
        try {
            backgroundImage1 = ImageIO.read(new File(
                   path + "BackGrounds/MenuBackGround.png"));
        
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        singlePlayerButton = new JButton("Single Player");
        singlePlayerButton.setSize(450, 50);
        singlePlayerButton.setLocation(800, 200);

        theButton2 = new JButton("Cooperative");

        theButton2.setSize(450, 50);
        theButton2.setLocation(800, 300);
        theButton3 = new JButton("Help");

        theButton3.setSize(450, 50);
        theButton3.setLocation(800, 400);
        theFrame = new JFrame("Absolute Assault");
        theFrame.setLocation(0, 0);
        theFrame.setResizable(false);
        theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        thePanel = new JGraphics();
        tiles = new InAnimate[1][1];
        tiles[0][0] = new InAnimate(0, 0, 1280, 720, backgroundImage1);
        thePanel.setTiles(tiles);

        thePanel.add(singlePlayerButton);
        singlePlayerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Set up for single player;
                startSinglePlayer();
            }

        });

        thePanel.add(theButton2);
        thePanel.add(theButton3);

        thePanel.addMouseMotionListener(this);
        thePanel.addKeyListener(this);
        thePanel.setLayout(null);
        thePanel.addMouseListener(this);
        thePanel.setFocusable(true);
        thePanel.setPreferredSize(new Dimension(1280, 720));
        theFrame.setContentPane(thePanel);
        theFrame.pack();
        theFrame.setVisible(true);

    }

    public static void main(String[] args) {

        AbsoluteAssault mm = new AbsoluteAssault();

        //

    }

    private void startSinglePlayer() {
     singlePlayerButton.setVisible(false);
     theButton2.setVisible(false);
     theButton3.setVisible(false);
     
     
     
        // TODO Auto-generated method stub
        // thePanel.setImage(backgroundImageSinglePlayer);

        // Load screen for single player
        BufferedReader br;
        String line = null;
        try {
         BufferedImage playerImages[] = new BufferedImage[5];
         //Read all images for player
         //String playerPath = "Character/standing/standingleft";
         
         //for (int i= 0; i < 4; i++) {
         // playerImages[i] = ImageIO.read(new File(path + "Character/standing/standingleft1.png"));
         //}
         
         playerImages[0] = ImageIO.read(new File(path + "Character/standing/standingleft1.png"));
         playerImages[1] = ImageIO.read(new File(path + "Character/walk/walkright1.png"));
         playerImages[2] = ImageIO.read(new File(path + "Character/walk/walkright3.png"));
         playerImages[3] = ImageIO.read(new File(path + "Character/attack/shootleft1.png"));
         playerImages[4] = ImageIO.read(new File(path + "Character/walk/walkright4.png"));
         
         // public Player(int intWidth, int intHeight, BufferedImage SpriteSheet[], boolean blnPrimary){
         player = new Player(60, 300, 45, 65, playerImages, true);
         
         thePanel.setPlayer(player);
         
            int x = 0;
            int y = 360;
            br = new BufferedReader(new FileReader(path + "singlePlayer.csv"));
            tiles = new InAnimate[100][20];
            int lineNumber = 0;
            TileType tileType = TileType.G1;
            InAnimate current;
            while ((line = br.readLine()) != null) {
                x = 0;
                String str[] = line.split(",");
                for (int j = 0; j < str.length; j++) {
                   // tileType = TileType.valueOf(str[j]);
                    current = createInAnimate(str[j], x, y);
                   
                    x = x + current.getWidth();

                    tiles[lineNumber][j] = current;
                }
                y = y + tiles[lineNumber][0].getHeight();
                lineNumber++;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
        
        
        thePanel.setTiles(tiles);
        thePanel.repaint();
    }
    
    private InAnimate createInAnimate(String code, int xForColumn, int yForRow) {
        BufferedImage image = null;
        int width, height, x = xForColumn, y = yForRow;
        String fileName;
        code = code.toLowerCase();
        // G1(72, 57), G2(48,66),G3(48,33),G4(24,38),GP(147,110),LE(239,287),RP(87,70);
        switch (code) {
        case "g1":
            width = 72; 
            height = 57;
           
            fileName = "grass1.png";
            break;
        case "g2":
            width = 48;
            height = 66;
            fileName = "grass2.png";
            break;
        case "g3":
            width = 48;
            height = 66;
            fileName = "grass3.png";
            break;
            
        case "g4":
         width = 24;
         height = 38;
         fileName = "grass4.png";
          break;
        case"gp":
            width = 147;
         height = 110;
         fileName = "GrassyPlatform.png";
          break;
        case "rp":
            width = 87;
            height = 70;
            fileName = "RockyPlatform.png";
            break;
        case"le":
          width = 239;
          height = 287;
         // y = y - 25;
         fileName ="LeftEdge.png";
          break;
        case "fl":
         width = 105;
         height= 77;
         fileName = "FenceLeft.png";
          break;
        case "fm":
         width = 80;
         height = 77;
         fileName = "FenceMid.png";
          break;
        case "fr" :
         width = 105;
         height = 77;
         fileName = "FenceRight.png";
          break;
        case "r1":
          y = y - 40;
         fileName = "rock1.png";
          break;
         
        case "r2":
         width= 83;
         height= 107;
         fileName = "Rock2.png ";
          break;
          
          
        default:
            width = 60;
            height = 40;
            fileName = "grass1.png";
            break;
    }
        
        if (fileName != null) {
            try {
                  image = ImageIO.read(new File(path + fileName ));;
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (image != null)
         return new InAnimate(x, y, image.getWidth(), image.getHeight(), image);
       
        return new InAnimate(x, y, 80, 120, null);
    }


 @Override
 public void keyPressed(KeyEvent e) {
  int keyCode = e.getKeyCode();
     switch( keyCode ) { 
      case KeyEvent.VK_F1:
       
       //Shoot attack
        blnAirBorne
       player.intState = 3;
       break;
         case KeyEvent.VK_UP:
             // handle up 
          player.jump();
          
             break;
         case KeyEvent.VK_DOWN:
          if (player.intY  < 300) {
           player.intY ++;
          }
             // handle down 
             break;
         case KeyEvent.VK_LEFT:
             // handle left
          player.currentDirection = Direction.Left;
          player.intState = 2;
          player.intX --;
             break;
         case KeyEvent.VK_RIGHT :
             // update state of player
          player.currentDirection = Direction.Right;
          player.intState = 2;
          player.intX ++;
             break;
      }
     thePanel.repaint();
  
 }

 @Override
 public void keyReleased(KeyEvent arg0) {
  // TODO Auto-generated method stub
 
  
 }

 @Override
 public void keyTyped(KeyEvent arg0) {
  // TODO Auto-generated method stub
 
  
 }

}