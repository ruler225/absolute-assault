package game;

public enum TileType {
    G1(72, 57), G2(48,66),G3(48,33),G4(24,38),GP(147,110),LE(239,287),RP(87,70);
	public int width;
	public int height;

	
	TileType(int w, int h) {
		width = w;
		height = h;
	}
	
}
