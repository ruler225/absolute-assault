
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

import javax.imageio.*;

import java.io.*;

import javax.swing.*;

//Define the states for the player
enum PlayerStates{StandRight,AttackLeft,WalkRight,WalkLeft,StandLeft,AttackRight,JumpRight,JumpLeft}

public class gamepanel extends JPanel implements KeyListener, ActionListener{
  //the background image
  private BufferedImage backgroundImg;
  
  private BufferedImage hudImg;
  private BufferedImage hudHeartImg;
  //the map tiles
  private inanimate[] tiles;
  // the player object
  private Player player;
  int frameCount = 0;
  
  private static final int MAX_PROJECTILE = 50;
  
  private static final int MAX_PROJECTILE_GOBLIN = 5;
  private Projectile[] projectiles;
  private int projectCount;
  
  private Projectile[] projectilesGoblin;
  private int projectCountGoblin;
  
  //the tile images
  private static BufferedImage gr = null;
  private static BufferedImage  le= null;
  private static BufferedImage re = null;
  private static BufferedImage r1b = null;
  private static BufferedImage r1 = null;
  private static BufferedImage m = null;
  private static BufferedImage mb = null;
  private static BufferedImage l1 = null;
  private static BufferedImage l1b = null;
  private static BufferedImage b = null;
  
  // for projectile
  private static BufferedImage projectileImg = null;
  private static BufferedImage projectileImgGoblin = null;
  
  private static BufferedImage screen = null;
  
  private static Graphics buffer = null;
    
  private static final int IMAGE_SIZE = 100;
  private static final int MAX_FRAMES = 4;
  private static final int ANIMATION_STATES =8;
  
  private static boolean blnNetworked = false;
  
  private Wizard wizard;
  
  private Goblin goblin;
  
  private Knight knight;
  
  JTextArea area = new JTextArea();
  // the timer
  Timer thetimer;
  //Constructor
  public gamepanel() {
   // area.setSize(300, 100);
   // area.setLocation(0, 0);
   // this.add(area);
    //read all the images Files
    
    
    BufferedReader br = null;
    FileReader fr = null;
    try {
      backgroundImg = ImageIO.read(new File("BackGrounds/sky.png"));
      r1 = ImageIO.read(new File("Map/island/R1.png"));
      r1b = ImageIO.read(new File("Map/island/R1B.png"));
      l1 = ImageIO.read(new File("Map/island/L1.png"));
      l1b = ImageIO.read(new File("Map/island/L1B.png"));
      m = ImageIO.read(new File("Map/island/M.png"));
      mb = ImageIO.read(new File("Map/island/MB.png"));
      le = ImageIO.read(new File("Map/grassplatform/le.png"));
      re = ImageIO.read(new File("Map/grassplatform/re.png"));
      gr = ImageIO.read(new File("Map/grassplatform/grass.png"));
      b  = ImageIO.read(new File("Map/grassplatform/black.png"));
      
      projectileImg = ImageIO.read(new File("Character/bullet.png"));
      projectileImgGoblin = ImageIO.read(new File("enemies/goblin/projectile.png"));

      
      hudImg = ImageIO.read(new File("HUD/HUD.png"));
      hudHeartImg = ImageIO.read(new File("HUD/100-percent.png"));
      
      //read csv file and create tiles
      //tile positions
      int x = 0; 
      int y = 0; 
      String line;      
      inanimate current;
      int intTileLength = 0;
      int intTileWidth = 0;
      int intCounter = 0;      
      //read the CSV file
      fr = new FileReader("Map/Level1.csv");
      br = new BufferedReader(fr);      
      
      //See how many elements should be loaded in the csv file
      while((line = br.readLine()) != null){
        String str[] = line.split(",");
        intTileLength += str.length;
        if(str.length > intTileWidth){
          intTileWidth = str.length;
        }
      }
      
      //Close FileReader and BufferedReader and reopen the file
      fr.close();
      br.close();
      fr = new FileReader("Map/Level1.csv");
      br = new BufferedReader(fr);
      
      // The (current) map 6X13. Change if map changes
      tiles = new inanimate[intTileLength];  //Change if map dimension changes
      while ((line = br.readLine()) != null) {
        x = 0; // each row start from x-position 0
        String str[] = line.split(","); // parses the string array
        for (int j = 0; j < str.length; j++) {  // the (current) map has 13 columns                    
          current = createInanimate(str[j], x, y);   //create an inAnimate object       
          x = x + IMAGE_SIZE;               //Get the x-position for the next tile
          tiles[intCounter] = current;               //
          intCounter ++;          
        }
        y = y + IMAGE_SIZE; // get the y-position of the next tile
      }
      screen = new BufferedImage(intTileWidth*100, 720, BufferedImage.TYPE_INT_ARGB);
      buffer = screen.createGraphics();
      // Read images for the player
      readImgForPlayers();
      
      readImgForGoblin();
      
      
      readImgForWizard();
      
      
      //projectiles
      projectiles = new Projectile[MAX_PROJECTILE];
      projectilesGoblin = new Projectile[MAX_PROJECTILE_GOBLIN];
     
    	  
      
    } catch (IOException e1) {    
      e1.printStackTrace();
    } finally{
      try{
         br.close();
         fr.close();
      }catch(IOException e){     
      }
    }
    this.addKeyListener(this);   
    // There are 1000 ms in a second.  Therefore 1000/60 = 60 frames per second
    thetimer = new Timer(1000/60, this);
    // Start the timer
    thetimer.start();
  }  
  
  /**
   * make the panel to be focusable so that it can respond to listeners
   **/
  public void addNotify(){
    super.addNotify();
    requestFocus();    
  }
  
  /**
   * create inanimate object with image and positions based on letters in CSV file
   **/
  private inanimate createInanimate(String code, int x, int y) {
    BufferedImage image = null;    
    code = code.toLowerCase(); // to avoid typing error    
    switch (code) {
      case "gr":
        image = gr;
        break;
      case "le":        
        image = le;
        break;
      case "re":
        image = re;
        break;        
      case "l1":        
        image = l1;
        break;
      case"l1b":
        image = l1b;
        break;
      case "r1":
        image = r1;
        break;
      case"r1b":        
        image = r1b;
        break;
      case "m":
        image = m;
        break;
      case "mb":
        image = mb;
        break;        
      case "b":
        image = b;
        break; 
      default:
        image = null;
        break;
    }
    
    if (image != null)
      //if there is an image...
      return new inanimate(x, y, image.getWidth(), image.getHeight(), image);
    else {
      //Most likely an empty space, will not return an inanimate object
      return null;
    }    
  } 
  
  /**
   * Paint
   **/
  public void paintComponent(Graphics g) {
	  frameCount ++;
    buffer.clearRect(0, 0, screen.getWidth(), screen.getHeight());
    //draw the background
    buffer.drawImage(backgroundImg,0,0,null); 
    
    //draw map tiles
    if(tiles != null){
      inanimate tile;      
      for (int j = 0; j < tiles.length; j++) {
        tile = tiles[j];
        if (tile != null) {  // to handle null cases
          tile.drawObject(buffer);          
        }
      }
    }
    
    if (player != null) {
      /*  for(;;){
       if(player.checkCollision(tiles[6][13])){
       player.blnAirborne = false;
       }
       }
       
       */       
      checkCollisions();
      
      if (isShot(player, player.getWidth(), player.getHeight())) {
    	  player.intLives --;
      }
      movePlayers();
      player.updateFrameCounter();
      player.updatePhysics();    
      player.drawObject(buffer);
      
      if(player.intX > screen.getWidth() - 1180){
        player.intX -= 5;
      }
      if(player.intX < 100){
        player.intX += 5;
      }
      
      // 
     // if (player.getCurrentState() == PlayerStates.AttackLeft.ordinal() || player.getCurrentState() == PlayerStates.AttackRight.ordinal()) {
      for (int i=0 ; i<MAX_PROJECTILE; i++) {
    	  Projectile projectile = projectiles[i];
    	  if (projectile != null) {
    		  	projectile.drawObject(buffer);
    		  	projectile.moveProjectile();    
    	  }
      }
      
      for (int i=0 ; i<MAX_PROJECTILE_GOBLIN; i++) {
    	  Projectile projectile = projectilesGoblin[i];
    	  if (projectile != null) {
    		  	projectile.drawObject(buffer);
    		  	projectile.moveProjectile();    
    	  }
      }
      
      // so it can show all the frames for die
      if (goblin != null && goblin.intHealth > -16) {
    	 if (goblin.intHealth > 0 ) {
    		 if (isEnemyShot(goblin, 50, 80)) {
    			 goblin.intHealth --;
    			 if (goblin.intHealth == 0) {
    				 if (goblin.getCurrentState() != 2)
    					 goblin.setAnimationState(2);
    	    	 }
    		 }
    	 } else {
    		 goblin.intHealth --;
    	 }
    	
    	 goblin.updateFrameCounter();
    	 if (goblin.getCurrentState() != 2) {
    		 Projectile pro = goblin.updateBehaviour(player);  
    		 if (pro != null && frameCount % 30 == 0) {
    			 if (goblin.currentDirection == Direction.Left) {
    				 pro.setPosition(goblin.intX - 20, goblin.intY);
    			 } else {
    				 pro.setPosition(goblin.intX + 90, goblin.intY);
    			 }
    			  // at most x projectiles
    			 	if (projectCountGoblin < MAX_PROJECTILE_GOBLIN) {
    		      	  projectilesGoblin[projectCountGoblin] = pro;
    		      	  projectCountGoblin ++;
    		        } else {
    		        	projectCountGoblin = 0;
    		        	projectilesGoblin[projectCountGoblin] = pro;
    		        }
    			 
    			 
    			 pro.drawObject(buffer);  
    			 pro.moveProjectile();    
    		 }
    		 goblin.updatePhysics();      
    	 }
    	 goblin.drawObject(buffer);
    }
      
      // draw wizard
      drawWizard();
     
      
     g.drawImage(screen.getSubimage(player.intX - 100, 0, 1280, 720), 0, 0, null);
     g.drawImage(hudImg, 0, 500, null);
     
     if (player.intLives > 0) {
    	 g.drawImage(hudHeartImg, 190, 543, null);
     }
     if (player.intLives > 50) {
    	 g.drawImage(hudHeartImg, 285, 543, null);
     }     
    }
    
    
  }  
  
  private boolean isEnemyShot(GameObject object, int width, int height) {
      for (int i=0 ; i<MAX_PROJECTILE; i++) {
    	  Projectile projectile = projectiles[i];
    	  if (projectile != null) {
    		  if (projectile.intX < object.intX + width && projectile.intX > object.intX
    		      &&  object.intY < projectile.intY && projectile.intY < object.intY + height) {
    			  return true;
    		  }
    	  }
      }
      return false;
  }

  private boolean isShot(GameObject object, int width, int height) {
      for (int i=0 ; i<MAX_PROJECTILE_GOBLIN; i++) {
    	  Projectile projectile = projectilesGoblin[i];
    	  if (projectile != null) {
    	
    		  int playerRight = player.intX + 45;
    		  int projectTileRight = projectile.intX + 25;
    		  int playerBot = player.intY + 70;
    		  int projectTileBot = projectile.intY + 30;
    	
    		  System.out.println("ddddddddddddd shot" + projectile.intX +  " " + projectile.intY);
			  System.out.println("obj shot" + object.intX +  " " + object.intY);
			  
    		  if (!(projectile.intX > object.intX + width ||  projectTileRight  < object.intX
    		      ||  projectile.intY > playerBot  || projectTileBot < object.intY )) {
    			  System.out.println("ddddddddddddd shot" + projectile.intX +  " " + projectile.intY);
    			  System.out.println("obj shot" + object.intX +  " " + object.intY);
    			  return true;
    		  }
    	  }
      }
      return false;
  }
  
 private void drawWizard() {
     
     // so it can show all the frames for die
     if (wizard != null && wizard.intHealth > -16) {
   	 if (wizard.intHealth > 0 ) {
   		 if (isEnemyShot(wizard, 50, 80)) {
   			wizard.intHealth --;
   			 if (wizard.intHealth == 0) {
   				 if (wizard.getCurrentState() != 2)
   					wizard.setAnimationState(2);
   	    	 }
   		 }
   	 } else {
   		wizard.intHealth --;
   	 }
   	
   	wizard.updateFrameCounter();
   	 if (wizard.getCurrentState() != 2) {
   		 Projectile pro = wizard.updateBehaviour(player);  
   		 if (pro != null) {
   			 if (wizard.currentDirection == Direction.Left) {
   				 pro.setPosition(wizard.intX - 20, wizard.intY);
   			 } else {
   				 pro.setPosition(wizard.intX + 90, wizard.intY);
   			 }
   			 
   			
   			 
   			 
   			 pro.drawObject(buffer);
   			 pro.moveProjectile();
   			 pro.moveProjectile();    // so that the projectiles looks apart
   		 }
   		 wizard.updatePhysics();      
   	 }
   	 wizard.drawObject(buffer);
   }
 }
   
  private void movePlayers(){
    if(player.blnMovingRight){
      player.intX += 5;
    }else if(player.blnMovingLeft){
      player.intX -= 5;
    }
  }
  
	private boolean checkProjectileHit() {
		boolean blnCollisionOccurred = false;
		for (int i = 0; i < tiles.length; i++) {
			// Make sure an inanimate object actually exists before checking
			// collision

			if (tiles[i] != null) {
				//if (projectile.checkCollision(tiles[i])) {
					
					return true;
				//}
						
			}
		}
		return false;
	}

  
  private void checkCollisions(){
    boolean blnCollisionOccurred = false;
   for(int i = 0;i < tiles.length;i++){
     //Make sure an inanimate object actually exists before checking collision
     
     if(tiles[i] != null){
      if(player.checkCollision(tiles[i]) && player.dblCurrentVelocity >=0){
        if(player.intY <= tiles[i].intY - player.getHeight()){
        player.blnAirborne = false;
        blnCollisionOccurred = true;
        player.intY = tiles[i].intY - player.getHeight();
        }else if(player.intY >= tiles[i].intY - player.getHeight()){
          if(player.intX < tiles[i].intX){
            player.intX -= 5;
          }else if(player.intX > tiles[i].intX){
            player.intX += 5;
          }
        }
      }
    }
   }
   
   if(!blnCollisionOccurred){
     player.blnAirborne = true;
   }
   
  }
  
  
  
  @Override // override the super class 
    
  public void keyPressed(KeyEvent e) {    
    int keyCode = e.getKeyCode();
    int currentState = player.getCurrentState();
    switch( keyCode ) { 
      case KeyEvent.VK_F1:        
        //Shoot attack      
        int nextState;
       
        if(currentState != PlayerStates.AttackLeft.ordinal() && currentState != PlayerStates.AttackRight.ordinal()){
        	nextState = PlayerStates.AttackRight.ordinal();
        	 player.currentDirection = Direction.Right;
          if(currentState == PlayerStates.StandLeft.ordinal() || currentState == PlayerStates.WalkLeft.ordinal()||currentState == PlayerStates.JumpLeft.ordinal()){
        	  nextState = PlayerStates.AttackLeft.ordinal();
        	  player.currentDirection = Direction.Left;
          }          
          player.setAnimationState(nextState);
        } 
        
        Projectile projectile = player.shootWeapon(projectileImg.getWidth(), projectileImg.getHeight(), 40, 2, projectileImg);
        if (player.getCurrentState() == PlayerStates.AttackRight.ordinal())
        	projectile.setPosition(player.intX + 50, player.intY + 33);
        else {
        	projectile.setPosition(player.intX - 50, player.intY + 33);
        }
        if (projectCount < MAX_PROJECTILE) {
      	  projectiles[projectCount] = projectile;
      	  projectCount ++;
        } else {
      	  projectCount = 0;
      	 projectiles[projectCount] = projectile;
        }
        break;
      case KeyEvent.VK_UP:
        // handle jump        
        // to do jump with collision checking
        player.setAnimationState(PlayerStates.JumpRight.ordinal());        
        player.jump();        
        break;
     // case KeyEvent.VK_DOWN:
     //  player.setAnimationState(PlayerStates.CrouchLeft.ordinal());   
       // player.intY ++;
      
        // handle down 
      //  break;
      case KeyEvent.VK_LEFT:
        // handle left        
        player.currentDirection = Direction.Left;
        player.setAnimationState(PlayerStates.WalkLeft.ordinal());   
        player.blnMovingLeft = true;
        break;
      case KeyEvent.VK_RIGHT :
        // update state of player
        player.currentDirection = Direction.Right;
        player.setAnimationState(PlayerStates.WalkRight.ordinal());   
        player.blnMovingRight = true;
        break;
    }    
  }
  
  public void actionPerformed(ActionEvent evt){
    if(evt.getSource() == thetimer){      
      repaint();
    }    
  }
  
  @Override
  public void keyReleased(KeyEvent evt) {
    int intKeyCode = evt.getKeyCode();
    int currentState = player.getCurrentState();
    int nextState = PlayerStates.StandRight.ordinal();
    if(currentState == PlayerStates.WalkLeft.ordinal() ||currentState == PlayerStates.JumpLeft.ordinal()||currentState == PlayerStates.AttackLeft.ordinal() ){
      nextState = PlayerStates.StandLeft.ordinal(); 
    }
    player.setAnimationState(nextState); 
     switch(intKeyCode){
    case KeyEvent.VK_LEFT:
      player.blnMovingLeft = false;
    case KeyEvent.VK_RIGHT:
      player.blnMovingRight = false;
  }
  }
  
 
  
  
  @Override
  public void keyTyped(KeyEvent evt) {
    
  }
  
  
  /**
   * Character states
   **/
  public void readImgForGoblin() {
    BufferedImage spriteSheet[][] = new BufferedImage[8][8];
    File folder = new File("enemies/goblin/attackleft");
    listFilesForFolder(folder, spriteSheet[0]); 
    
    folder = new File("enemies/goblin/attackright");
    listFilesForFolder(folder, spriteSheet[1]);
    
    folder = new File("enemies/goblin/dieleft");
    listFilesForFolder(folder, spriteSheet[2]);
    
    folder = new File("enemies/goblin/dieright");
    listFilesForFolder(folder, spriteSheet[3]);
    
    folder = new File("enemies/goblin/idleleft");
    listFilesForFolder(folder, spriteSheet[4]);
    
    folder = new File("enemies/goblin/idleright");
    listFilesForFolder(folder, spriteSheet[5]);
    
    folder = new File("enemies/goblin/walkleft");
    listFilesForFolder(folder, spriteSheet[6]);
    
    folder = new File("enemies/goblin/walkright");
    listFilesForFolder(folder, spriteSheet[7]);
    
  // folder = new File("Character/holdingdefault/crouchleft");
   // listFilesForFolder(folder, spriteSheet[8]);
   //  folder = new File("Character/holdingdefault/crouchright");
   // listFilesForFolder(folder, spriteSheet[9]);
    
    //create player
  
    goblin = new Goblin(1000, 350, 72, 78, 100, 0, projectileImgGoblin, spriteSheet);
    goblin.intHealth = 20;
    
  }
  
  
  
  /**
   * Character states //////////////////////////////////////////////////////////////////////////////////////////
   * 
   **/
  public void readImgForWizard() {
    BufferedImage spriteSheet[][] = new BufferedImage[8][8];   ///////alos changed player to have 100 lives
    File folder = new File("enemies/goblin/attackleft");    ////////////////////////////// change to folder for wizard.
    listFilesForFolder(folder, spriteSheet[0]); 
    
    folder = new File("enemies/goblin/attackright");
    listFilesForFolder(folder, spriteSheet[1]);
    
    folder = new File("enemies/goblin/dieleft");
    listFilesForFolder(folder, spriteSheet[2]);
    
    folder = new File("enemies/goblin/dieright");
    listFilesForFolder(folder, spriteSheet[3]);
    
    folder = new File("enemies/goblin/idleleft");
    listFilesForFolder(folder, spriteSheet[4]);
    
    folder = new File("enemies/goblin/idleright");
    listFilesForFolder(folder, spriteSheet[5]);
    
    folder = new File("enemies/goblin/walkleft");
    listFilesForFolder(folder, spriteSheet[6]);
    
    folder = new File("enemies/goblin/walkright");
    listFilesForFolder(folder, spriteSheet[7]);

    //create wizard
  
    wizard = new Wizard(300, 350, 72, 78, 100, 0, projectileImgGoblin, spriteSheet);
    wizard.intHealth = 20;
    
  }
  
  /**
   * Character states
   **/
  public void readImgForPlayers() {
    BufferedImage spriteSheet[][] = new BufferedImage[ANIMATION_STATES][MAX_FRAMES];
    File folder = new File("Character/holdingdefault/standright");
    listFilesForFolder(folder, spriteSheet[0]); 
    
    folder = new File("Character/holdingdefault/attackLeft");
    listFilesForFolder(folder, spriteSheet[1]);
    
    folder = new File("Character/holdingdefault/walkright");
    listFilesForFolder(folder, spriteSheet[2]);
    
    folder = new File("Character/holdingdefault/walkleft");
    listFilesForFolder(folder, spriteSheet[3]);
    
    folder = new File("Character/holdingdefault/standleft");
    listFilesForFolder(folder, spriteSheet[4]);
    
    folder = new File("Character/holdingdefault/attackright");
    listFilesForFolder(folder, spriteSheet[5]);
    
    folder = new File("Character/holdingdefault/jumpright");
    listFilesForFolder(folder, spriteSheet[6]);
    
    folder = new File("Character/holdingdefault/jumpleft");
    listFilesForFolder(folder, spriteSheet[7]);
    
  // folder = new File("Character/holdingdefault/crouchleft");
   // listFilesForFolder(folder, spriteSheet[8]);
   //  folder = new File("Character/holdingdefault/crouchright");
   // listFilesForFolder(folder, spriteSheet[9]);
    
    //create player
    player = new Player(200,200,45,70,spriteSheet,true);    
  }
  
  /**
   * read all files in the folder and create the image
   **/
  
  
  public void listFilesForFolder(final File folder, BufferedImage imagesForState[]) {
    int i = 0;
    for (final File fileEntry : folder.listFiles()) {      
      // load image.....
      try {
        BufferedImage image = ImageIO.read(fileEntry);
        imagesForState[i] = image;
        i ++;
      }catch(IOException e1){
         e1.printStackTrace();
      } 
    }    
  } 
  
}